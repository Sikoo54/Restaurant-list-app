const CONFIG = {
  BASE_URL: 'https://restaurant-api.dicoding.dev/', // Base URL dari API Dicoding
  BASE_IMAGE_URL: 'https://restaurant-api.dicoding.dev/images/large/', // URL untuk gambar
  CACHE_NAME: 'RestaurantCatalogue-V1', // Nama cache untuk aplikasi Anda
  DEFAULT_LANGUAGE: 'en-us', // Bahasa (jika dibutuhkan)
};

export default CONFIG;
