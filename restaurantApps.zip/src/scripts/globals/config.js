const CONFIG = {
  DATABASE_NAME: 'restaurant-database', // Nama database
  DATABASE_VERSION: 1, // Versi database
  OBJECT_STORE_NAME: 'restaurants', // Nama object store
  // CACHE_NAME: 'FoodHunter-V1',
};

export default CONFIG;
